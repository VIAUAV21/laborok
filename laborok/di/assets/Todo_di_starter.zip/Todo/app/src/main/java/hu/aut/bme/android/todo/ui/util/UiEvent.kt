package hu.aut.bme.android.todo.ui.util

import hu.aut.bme.android.todo.ui.model.UiText

sealed class UiEvent {
    object Success: UiEvent()
    data class Failure(val message: UiText): UiEvent()
}