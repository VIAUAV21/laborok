package hu.aut.bme.android.todo.feature.todo_check

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import hu.aut.bme.android.todo.R
import hu.aut.bme.android.todo.ui.common.DatePickerDialog
import hu.aut.bme.android.todo.ui.common.TodoAppBar
import hu.aut.bme.android.todo.ui.common.TodoEditor
import hu.aut.bme.android.todo.ui.model.TodoUi
import hu.aut.bme.android.todo.ui.util.UiEvent
import kotlinx.coroutines.launch
import kotlinx.datetime.toLocalDate

@ExperimentalComposeUiApi
@ExperimentalMaterial3Api
@Composable
fun CheckTodoScreen(
    onNavigateBack: () -> Unit,
    viewModel: CheckTodoViewModel = viewModel(factory = CheckTodoViewModel.Factory)
) {

    val state by viewModel.state.collectAsStateWithLifecycle()

    var showDialog by remember { mutableStateOf(false) }
    val hostState = remember { SnackbarHostState() }

    val scope = rememberCoroutineScope()

    val context = LocalContext.current

    LaunchedEffect(key1 = true) {
        viewModel.uiEvent.collect { uiEvent ->
            when (uiEvent) {
                is UiEvent.Success -> { onNavigateBack() }
                is UiEvent.Failure -> {
                    scope.launch {
                        hostState.showSnackbar(uiEvent.message.asString(context))
                    }
                }
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState) },
        topBar = {
            if (!state.isLoadingTodo) {
                TodoAppBar(
                    title = if (state.isEditingTodo) {
                        stringResource(id = R.string.app_bar_title_edit_todo)
                    } else state.todo?.title ?: "Todo",
                    onNavigateBack = onNavigateBack,
                    actions = {
                        IconButton(
                            onClick = {
                                if (state.isEditingTodo) {
                                    viewModel.onEvent(CheckTodoEvent.StopEditingTodo)
                                } else {
                                    viewModel.onEvent(CheckTodoEvent.EditingTodo)
                                }
                            }
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null)
                        }
                        IconButton(
                            onClick = {
                                viewModel.onEvent(CheckTodoEvent.DeleteTodo)
                            }
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = null)
                        }
                    }
                )
            }
        },
        floatingActionButton = {
            if (state.isEditingTodo) {
                LargeFloatingActionButton(
                    onClick = {
                        viewModel.onEvent(CheckTodoEvent.UpdateTodo)
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null)
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentAlignment = Alignment.Center
        ) {
            if (state.isLoadingTodo) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.secondaryContainer
                )
            } else {
                val todo = state.todo ?: TodoUi()
                TodoEditor(
                    titleValue = todo.title,
                    titleOnValueChange = { viewModel.onEvent(CheckTodoEvent.ChangeTitle(it)) },
                    descriptionValue = todo.description,
                    descriptionOnValueChange = { viewModel.onEvent(CheckTodoEvent.ChangeDescription(it)) },
                    selectedPriority = todo.priority,
                    onPrioritySelected = { viewModel.onEvent(CheckTodoEvent.SelectPriority(it)) },
                    pickedDate = todo.dueDate.toLocalDate(),
                    onDatePickerClicked = {
                        showDialog = true
                    },
                    modifier = Modifier,
                    enabled = state.isEditingTodo
                )
                if (showDialog) {
                    DatePickerDialog(
                        currentDate = todo.dueDate.toLocalDate(),
                        onConfirm = { date ->
                            viewModel.onEvent(CheckTodoEvent.SelectDate(date))
                            showDialog = false
                        },
                        onDismiss = {
                            showDialog = false
                        }
                    )
                }
            }
        }
    }
}