package hu.aut.bme.android.todo.feature.todo_create

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import hu.aut.bme.android.todo.TodoApplication
import hu.aut.bme.android.todo.domain.model.Todo
import hu.aut.bme.android.todo.domain.usecases.TodoUseCases
import hu.aut.bme.android.todo.ui.model.*
import hu.aut.bme.android.todo.ui.util.UiEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.datetime.LocalDate
import java.time.LocalDateTime

class CreateTodoViewModel(
    private val todoOperations: TodoUseCases
) : ViewModel() {

    private val _state = MutableStateFlow(CreateTodoState())
    val state = _state.asStateFlow()

    private val _uiEvent = Channel<UiEvent>()
    val uiEvent = _uiEvent.receiveAsFlow()

    fun onEvent(event: CreateTodoEvent) {
        when(event) {
            is CreateTodoEvent.ChangeTitle -> {
                val newValue = event.text
                _state.update { it.copy(
                    todo = it.todo.copy(title = newValue)
                ) }
            }
            is CreateTodoEvent.ChangeDescription -> {
                val newValue = event.text
                _state.update { it.copy(
                    todo = it.todo.copy(description = newValue)
                ) }
            }
            is CreateTodoEvent.SelectPriority -> {
                val newValue = event.priority
                _state.update { it.copy(
                    todo = it.todo.copy(priority = newValue)
                ) }
            }
            is CreateTodoEvent.SelectDate -> {
                val newValue = event.date
                _state.update { it.copy(
                    todo = it.todo.copy(dueDate = newValue.toString())
                ) }
            }
            CreateTodoEvent.SaveTodo -> {
                onSave()
            }
        }
    }

    private fun onSave() {
        viewModelScope.launch {
            try {
                todoOperations.saveTodo(state.value.todo.asTodo())
                _uiEvent.send(UiEvent.Success)
            } catch (e: Exception) {
                _uiEvent.send(UiEvent.Failure(e.toUiText()))
            }
        }
    }

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val todoOperations = TodoUseCases(TodoApplication.repository)
                CreateTodoViewModel(
                    todoOperations = todoOperations
                )
            }
        }
    }

}

data class CreateTodoState(
    val todo: TodoUi = TodoUi()
)

sealed class CreateTodoEvent {
    data class ChangeTitle(val text: String): CreateTodoEvent()
    data class ChangeDescription(val text: String): CreateTodoEvent()
    data class SelectPriority(val priority: PriorityUi): CreateTodoEvent()
    data class SelectDate(val date: LocalDate): CreateTodoEvent()
    object SaveTodo: CreateTodoEvent()
}
