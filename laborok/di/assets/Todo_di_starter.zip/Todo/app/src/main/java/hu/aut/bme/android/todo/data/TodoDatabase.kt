package hu.aut.bme.android.todo.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import hu.aut.bme.android.todo.data.converters.LocalDateConverter
import hu.aut.bme.android.todo.data.converters.TodoPriorityConverter
import hu.aut.bme.android.todo.data.dao.TodoDao
import hu.aut.bme.android.todo.data.entities.TodoEntity

@Database(entities = [TodoEntity::class], version = 1)
@TypeConverters(TodoPriorityConverter::class, LocalDateConverter::class)
abstract class TodoDatabase : RoomDatabase() {
    abstract val dao: TodoDao
}