package hu.aut.bme.android.todo.domain.usecases

import hu.aut.bme.android.todo.data.datasource.TodoRepository
import hu.aut.bme.android.todo.domain.model.Todo
import hu.aut.bme.android.todo.domain.model.asTodoEntity

class UpdateTodoUseCase(private val repository: TodoRepository) {

    suspend operator fun invoke(todo: Todo) {
        repository.updateTodo(todo.asTodoEntity())
    }

}