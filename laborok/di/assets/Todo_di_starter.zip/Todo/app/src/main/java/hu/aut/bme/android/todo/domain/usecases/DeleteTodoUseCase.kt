package hu.aut.bme.android.todo.domain.usecases

import hu.aut.bme.android.todo.data.datasource.TodoRepository


class DeleteTodoUseCase(private val repository: TodoRepository) {

    suspend operator fun invoke(id: Int) {
        repository.deleteTodo(id)
    }

}