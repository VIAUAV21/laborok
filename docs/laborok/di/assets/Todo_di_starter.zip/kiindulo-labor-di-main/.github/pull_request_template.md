#### Emlékeztető a _pull request_ használatáról

- A megoldásod a laborvezető fogja pontozni, ennél a labornál nincs automatikus értékelés.
- A laborvezetődhöz akkor rendeld a pull request-et, amikor készen vagy, és beadod a megoldást.
- Ne merge-eld a pull request-et.

A folyamatot részletesen lásd itt: <https://viauav21.github.io/laborok/tudnivalok/github/GitHub/>
